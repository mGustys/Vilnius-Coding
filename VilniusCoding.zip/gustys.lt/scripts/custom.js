



//Burger menu

function myFunction() {
    var x = document.getElementById("myNavigation");
    var y = document.getElementById("animation");
  if (x.className === "navigation") {
    x.className += " responsive";
    y.classList.toggle("change");
  } else {
    x.className = "navigation";
    y.classList.toggle("change");
  }
}   
 

//Slick Slider

 $('.single-item').slick({
    autoplay: true,
    autoplaySpeed: 3000,
    dots: true,
    arrows: false,
});
  
      
      